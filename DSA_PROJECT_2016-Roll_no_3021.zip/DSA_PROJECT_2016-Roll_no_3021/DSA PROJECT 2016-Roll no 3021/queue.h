#include<stdio.h>
queue1()
{int choicequeue;
while(1)
{
printf("1-> for array queue\n") ;
printf("2-> for link queue\n");
printf("3-> for circular array queue\n");
printf("4-> for circular link queue\n");
printf("5-> for double ended queue\n");
printf("6-> for another option\n");
printf("enter your choice =");
scanf("%d",&choicequeue);
switch(choicequeue)
{
case 1:
    q();
    break;
case 2:
    qlink();
    break;
case 3:
    cq();
    break;
case 4:
    cqlink();
    break;
case 5:
    dq();
    break;
case 6:
    main();
    break;
}
    system("pause");
    system("cls");}}
