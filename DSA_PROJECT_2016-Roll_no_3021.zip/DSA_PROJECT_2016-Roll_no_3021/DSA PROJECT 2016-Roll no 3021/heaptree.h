#include <stdio.h>
#define MAX_VAL 9999   /*All values in heap should be less than this value*/

void heapinsert(int num, int arr[], int *p_hsize);
int heapdel_root(int arr[], int *p_hsize);
void restoreUp(int arr[], int loc);
void restoreDown(int arr[], int i, int size);
void buildHeap(int arr[], int size );
void heapdisplay(int arr[],int hsize);

heaptree( )
{
	int arr[100];
	int hsize=0;
	int i,choice,num;

	arr[0]= MAX_VAL;

	while(1)
	{
		printf("1.Insert\n");
		printf("2.Delete root\n");
		printf("3.Display\n");
		printf("4.Build Heap\n");
		printf("5.for another option\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);
		switch(choice)
		{
		 case 1:
			printf("Enter the number to be inserted : ");
			scanf("%d",&num);
			heapinsert(num,arr,&hsize);
			break;
		 case 2:
			if(hsize==0)
				printf("Heap is empty \n");
			else
			{
				num = heapdel_root(arr,&hsize);
				printf("Maximum element is %d\n", num);
			}
			break;
		 case 3:
			heapdisplay(arr,hsize);
			break;
 		 case 4:
			printf("Enter size of the array ");
			scanf("%d",&hsize);
			printf("Enter array : ");
			for(i=1;i<=hsize;i++)
				scanf("%d",&arr[i]);
			buildHeap(arr,hsize);
			break;
		 case 5:
			tree1();
			break;
		 default:
			printf("Wrong choice\n");
		}
		system("pause");
   system("cls");
	}}

void heapinsert(int num, int arr[], int *p_hsize )
{
	(*p_hsize)++;
	arr[*p_hsize]=num;
	restoreUp(arr, *p_hsize);
}
void restoreUp(int arr[], int i)
{
	int k = arr[i];
	int par = i/2;

	/* while( par>=1 && arr[par] < num  )*/  /*if MAX_VAL not in arr[0]*/
	while( arr[par] < k  )
	{
		arr[i]=arr[par];
		i = par;
		par = i/2;
	}
	arr[i] = k;
}/*End of restoreUp()*/

int heapdel_root(int arr[], int *p_hsize)
{
	int max = arr[1];
	(*p_hsize)--;
	restoreDown(arr,1,*p_hsize);
	return max;
}

void restoreDown(int arr[], int i, int hsize )
{
	int lchild=2*i, rchild=lchild+1;

	int num=arr[i];

	while( rchild <= hsize )
	{
		if( num>=arr[lchild] && num>=arr[rchild] )
		{
			arr[i] = num;
			return;
		}
		else if(arr[lchild] > arr[rchild])
		{
			arr[i] = arr[lchild];
			i = lchild;
		}
		else
		{
			arr[i] = arr[rchild];
			i = rchild;
		}
		lchild = 2 * i;
		rchild = lchild + 1;
	}

	if(lchild == hsize && num < arr[lchild] )
	{
		arr[i]=arr[lchild];
		i = lchild;
	}
	arr[i]=num;
}

void heapdisplay(int arr[],int hsize)
{
	int i;
	if(hsize==0)
	{
		printf("Heap is empty\n");
		return;
	}
	for(i=1;i<=hsize;i++)
		printf("%d ",arr[i]);
	printf("\n");

	printf("Number of elements = %d\n",hsize);
}

void buildHeap(int arr[], int size )
{
	int i;
	for(i=2; i<=size; i++)
		restoreUp(arr,i);
}/*End of buildHeap()*/

/*Bottom up approach*/
/* void buildHeap(int arr[], int size )
{
	int i;
	for(i=size/2; i>=1; i--)
		restoreDown(arr,i,size);
}*/

