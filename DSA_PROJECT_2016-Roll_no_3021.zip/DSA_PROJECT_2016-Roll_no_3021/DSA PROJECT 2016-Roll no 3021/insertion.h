
#include<stdio.h>
insertion()
{int n,i,j,k;
printf("enter the number of element\n");
scanf("%d",&n);
int ar[n];
printf("enter the elements of arrays\n");
for(i=0;i<n;i++)
{scanf("%d",&ar[i]);}
for(i=1;i<n;i++)
{k=ar[i];
    for(j=i-1;j>=0&&k<ar[j];j--)
{ar[j+1]=ar[j];}
ar[j+1]=k;
}
for(i=0;i<n;i++)
printf("%d\n",ar[i]);



system("pause");
   system("cls");
   sort1();

}

