#include<stdio.h>
tree1()
{int choicetree;
while(1)
{
printf("1-> for complete binary tree\n") ;
printf("2-> for binary search tree \n");
printf("3-> for threaded tree\n");
printf("4-> for expression tree\n");
printf("5-> for heap tree\n");
printf("6-> for AVL for tree\n");
printf("7-> for another option\n");
printf("enter your choice =");
scanf("%d",&choicetree);
switch(choicetree)
{
case 1:
    complete();
    break;
case 2:
    bst();
    break;
case 3:
   threded();
    break;
case 4:
    exptree();
    break;
case 5:
    heaptree();
    break;
case 6:
    AVL();
    break;
case 7:
    main();
    break;}
    system("pause");
    system("cls");}}

