
#include<stdio.h>
bubble()
{int i,j,n,counter,swap;
printf("enter the size of array\n");
scanf("%d",&n);
int ar[n];
printf("enter the elements of an array\n");
for(i=0;i<n;i++)
{scanf("%d",&ar[i]);}
for(i=0;i<n-1;i++)
{counter=0;
    for(j=0;j<n-1-i;j++)
{
if(ar[j]>ar[j+1])
{swap=ar[j];
ar[j]=ar[j+1];
ar[j+1]=swap;
counter++;
}

}if(counter==0)
    break;
}

for(i=0;i<n;i++)
{printf("%d\n",ar[i]);

}
system("pause");
system("cls");
sort1();

}

