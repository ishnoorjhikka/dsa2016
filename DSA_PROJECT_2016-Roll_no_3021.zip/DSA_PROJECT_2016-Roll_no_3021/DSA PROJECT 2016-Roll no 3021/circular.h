#include<stdio.h>
#include<stdlib.h>

struct circular
{
	int info;
	struct circular *link;
};

struct circular *ccreate_list(struct circular *last);
void cdisplay(struct circular *last);
struct circular *caddtoempty(struct circular *last,int data);
struct circular *caddatbeg(struct circular *last,int data);
struct circular *caddatend(struct circular *last,int data);
struct circular *caddafter(struct circular *last,int data,int item);
struct circular *cdel(struct circular *last,int data);

clink()
{
	int choice,data,item;
	struct circular	*last=NULL;

	while(1)
	{
		printf("1.Create List\n");
		printf("2.Display\n");
		printf("3.Add to empty list\n");
		printf("4.Add at beginning\n");
		printf("5.Add at end\n");
		printf("6.Add after \n");
		printf("7.Delete\n");
		printf("8.for another option\n");

		printf("Enter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		 case 1:
			last=ccreate_list(last);
			break;
		 case 2:
			cdisplay(last);
			break;
		 case 3:
			printf("Enter the element to be inserted : ");
			scanf("%d",&data);
			last=caddtoempty(last,data);
			break;
		 case 4:
			printf("Enter the element to be inserted : ");
			scanf("%d",&data);
			last=caddatbeg(last,data);
			break;
		 case 5:
			printf("Enter the element to be inserted : ");
			scanf("%d",&data);
			last=caddatend(last,data);
			break;
		 case 6:
			printf("Enter the element to be inserted : ");
			scanf("%d",&data);
			printf("Enter the element after which to insert : ");
			scanf("%d",&item);
			last=caddafter(last,data,item);
			break;
		 case 7:
			printf("Enter the element to be deleted : ");
			scanf("%d",&data);
			last=cdel(last,data);
			break;
		 case 8:
		 	list1();
		 	break;
		 default:
			printf("Wrong choice\n");
		}
		system("pause");
   system("cls");
	}
}

struct circular *ccreate_list(struct circular *last)
{
	int i,n,data;
	printf("Enter the number of circulars : ");
	scanf("%d",&n);
	last=NULL;
	if(n==0)
		return last;
	printf("Enter the element to be inserted : ");
	scanf("%d",&data);
	last=caddtoempty(last,data);

	for(i=2;i<=n;i++)
	{
		printf("Enter the element to be inserted : ");
		scanf("%d",&data);
		last=caddatend(last,data);
	}
	return last;
}/*End of create_list()*/

struct circular *caddtoempty(struct circular *last,int data)
{
	struct circular *tmp;
	tmp=(struct circular *)malloc(sizeof(struct circular));
	tmp->info=data;
	last=tmp;
	last->link=last;
	return last;
}/*End of addtoempty( )*/

struct circular *caddatbeg(struct circular *last,int data)
{
	struct circular *tmp;
	tmp=(struct circular *)malloc(sizeof(struct circular));
	tmp->info=data;
	tmp->link=last->link;
	last->link=tmp;
	return last;
}/*End of addatbeg( )*/

struct circular *caddatend(struct circular *last,int data)
{
	struct circular *tmp;
	tmp=(struct circular *)malloc(sizeof(struct circular));
	tmp->info=data;
	tmp->link=last->link;
	last->link=tmp;
	last=tmp;
	return last;
}/*End of addatend( )*/

struct circular *caddafter(struct circular *last,int data,int item)
{
	struct circular *tmp,*p;
	p=last->link;
	do
	{
		if(p->info==item)
		{
			tmp=(struct circular *)malloc(sizeof(struct circular));
			tmp->info=data;
			tmp->link=p->link;
			p->link=tmp;
			if(p==last)
				last=tmp;
			return last;
		}
		p=p->link;
	}while(p!=last->link);
	printf("%d not present in the list\n",item);
	return last;
}/*End of addafter()*/

struct circular *cdel(struct circular *last,int data)
{
	struct circular *tmp,*p;
	if(last==NULL)
	{
		printf("List is empty\n");
		return last;
	}
	/*Deletion of only circular*/
	if(last->link==last && last->info==data)
	{
		tmp=last;
		last=NULL;
		free(tmp);
		return last;
	}
	/*Deletion of first circular*/
	if(last->link->info==data)
	{
		tmp=last->link;
		last->link=tmp->link;
		free(tmp);
		return last;
	}
	/*Deletion in between*/
	p=last->link;
	while(p->link!=last)
	{
		if(p->link->info==data)
		{
			tmp=p->link;
			p->link=tmp->link;
			free(tmp);
			return last;
		}
		p=p->link;
	}
	/*Deletion of last circular*/
	if(last->info==data)
	{
		tmp=last;
		p->link=last->link;
		last=p;
		free(tmp);
		return last;
	}
	printf("Element %d not found\n",data);
	return last;
}/*End of del( )*/

void cdisplay(struct circular *last)
{
	struct circular *p;
	if(last==NULL)
	{
		printf("List is empty\n");
		return;
	}
	p=last->link;
	do
	{
		printf("%d ",p->info);
		p=p->link;
	}while(p!=last->link);
	printf("\n");
}/*End of display( )*/

