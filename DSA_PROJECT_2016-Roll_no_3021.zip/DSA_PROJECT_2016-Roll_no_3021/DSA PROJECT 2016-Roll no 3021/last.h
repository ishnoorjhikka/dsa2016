#include <stdio.h>
last()
{
printf("#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#__#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_\n");
int i;
    for(i=0;i<97;i++)
        printf("=");
    printf("\nSubmitted By:\t\t\t\t\t\t\t\t\tSubmitted To:  \t|\n");
    for(i=0;i<97;i++)
        printf("=");
    printf("\nMr. Ashish Kumar\t\t\t\t\t\t\t\tYash Dubey    \t|\n");
    printf("\nAsst. Professor\t\t\t\t\t\t\t\t\t15103044    \t|\n");
    printf("\nDept. of CSE   \t\t\t\t\t\t\t\t\t3rd Semester   \t|\n");
    for(i=0;i<97;i++)
        printf("=");

printf("#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#__#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_#_\n");

exit(1);

}
