/*P6.3 Recursive operations in Binary Search Tree*/
#include<stdio.h>
#include<stdlib.h>

struct bst
{
	struct bst *lchild;
	int info;
	struct bst *rchild;
};

struct bst *bstsearch(struct bst *ptr, int skey);
struct bst *bstinsert(struct bst *ptr, int ikey);
struct bst *bstdel(struct bst *ptr, int dkey);
struct bst *bstMin(struct bst *ptr);
struct bst *bstMax(struct bst *ptr);
int bstheight(struct bst *ptr);
void bstpreorder(struct bst *ptr);
void bstinorder(struct bst *ptr);
void bstpostorder(struct bst *ptr);

bst( )
{
	struct bst *root=NULL,*ptr;
	int choice,k;

	while(1)
	{
		printf("\n");
		printf("1.Search\n");
		printf("2.Insert\n");
		printf("3.Delete\n");
		printf("4.Preorder Traversal\n");
		printf("5.Inorder Traversal\n");
		printf("6.Postorder Traversal\n");
		printf("7.Height of tree\n");
		printf("8.Find minimum and maximum\n");
		printf("9.for another option\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		case 1:
			printf("Enter the key to be searched : ");
			scanf("%d",&k);
			ptr = bstsearch(root, k);
			if(ptr!=NULL)
				printf("Key found\n");
			break;
		case 2:
			printf("Enter the key to be inserted : ");
			scanf("%d",&k);
			root = bstinsert(root, k);
			break;
		case 3:
			printf("Enter the key to be deleted : ");
			scanf("%d",&k);
			root = bstdel(root,k);
			break;
		 case 4:
			bstpreorder(root);
			break;
		 case 5:
			bstinorder(root);
			break;
		 case 6:
			bstpostorder(root);
			break;
		 case 7:
			 printf("Height of tree is %d\n", bstheight(root));
			 break;
		 case 8:
			ptr = bstMin(root);
			if(ptr!=NULL)
				printf("Minimum key is %d\n", ptr->info );
			ptr = bstMax(root);
			if(ptr!=NULL)
				printf("Maximum key is %d\n", ptr->info );
			break;
		 case 9:
			tree1();
			break;
		 default:
			printf("Wrong choice\n");
		}system("pause");
   system("cls");
	}}

struct bst *bstsearch(struct bst *ptr, int skey)
{
	if(ptr==NULL)
	{
		printf("key not found\n");
		return NULL;
	}
	else if(skey < ptr->info)/*search in left subtree*/
		return bstsearch(ptr->lchild, skey);
	else if(skey > ptr->info)/*search in right subtree*/
		return bstsearch(ptr->rchild, skey);
	else /*skey found*/
		return ptr;
}/*End of search()*/

struct bst *bstinsert(struct bst *ptr, int ikey )
{
	if(ptr==NULL)
	{
		ptr = (struct bst *) malloc(sizeof(struct bst));
		ptr->info = ikey;
		ptr->lchild = NULL;
		ptr->rchild = NULL;
	}
	else if(ikey < ptr->info)	/*Insertion in left subtree*/
		ptr->lchild = bstinsert(ptr->lchild, ikey);
	else if(ikey > ptr->info)	/*Insertion in right subtree */
		ptr->rchild = bstinsert(ptr->rchild, ikey);
	else
		printf("Duplicate key\n");
	return ptr;
}/*End of insert( )*/

struct bst *bstdel(struct bst *ptr, int dkey)
{
	struct bst *tmp, *succ;

	if( ptr == NULL)
	{
		printf("dkey not found\n");
		return(ptr);
	}
	if( dkey < ptr->info )/*delete from left subtree*/
		ptr->lchild = bstdel(ptr->lchild, dkey);
	else if( dkey > ptr->info )/*delete from right subtree*/
		ptr->rchild = bstdel(ptr->rchild, dkey);
	else
	{
		/*key to be deleted is found*/
		if( ptr->lchild!=NULL  &&  ptr->rchild!=NULL )  /*2 children*/
		{
			succ=ptr->rchild;
			while(succ->lchild)
				succ=succ->lchild;
			ptr->info=succ->info;
			ptr->rchild = bstdel(ptr->rchild, succ->info);
		}
		else
		{
			tmp = ptr;
			if( ptr->lchild != NULL ) /*only left child*/
				ptr = ptr->lchild;
			else if( ptr->rchild != NULL) /*only right child*/
				ptr = ptr->rchild;
			else	/* no child */
				ptr = NULL;
			free(tmp);
		}
	}
	return ptr;
}/*End of del( )*/

struct bst *bstMin(struct bst *ptr)
{
	if(ptr==NULL)
		return NULL;
	else if(ptr->lchild==NULL)
        return ptr;
	else
		return bstMin(ptr->lchild);
}/*End of min()*/

struct bst *bstMax(struct bst *ptr)
{
	if(ptr==NULL)
		return NULL;
	else if(ptr->rchild==NULL)
        return ptr;
	else
		return bstMax(ptr->rchild);
}/*End of max()*/

void bstpreorder(struct bst *ptr)
{
	if(ptr == NULL )	/*Base Case*/
		return;
	printf("%d  ",ptr->info);
	bstpreorder(ptr->lchild);
	bstpreorder(ptr->rchild);
}/*End of preorder( )*/

void bstinorder(struct bst *ptr)
{
	if(ptr == NULL )/*Base Case*/
		return;
	bstinorder(ptr->lchild);
	printf("%d  ",ptr->info);
	bstinorder(ptr->rchild);
}/*End of inorder( )*/

void bstpostorder(struct bst *ptr)
{
	if(ptr == NULL )/*Base Case*/
		return;
	bstpostorder(ptr->lchild);
	bstpostorder(ptr->rchild);
	printf("%d  ",ptr->info);

}/*End of postorder( )*/

int bstheight(struct bst *ptr)
{
	int h_left, h_right;

	if (ptr == NULL) /*Base Case*/
		return 0;

	h_left =  bstheight(ptr->lchild);
	h_right = bstheight(ptr->rchild);

	if (h_left > h_right)
		return 1 + h_left;
	else
		return 1 + h_right;
}/*End of height()*/

