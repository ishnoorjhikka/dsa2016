#include<stdio.h>
#include<conio.h>
#include<malloc.h>
#include<stdlib.h>
#include<string.h>

struct Etree
{
    char data;
    struct Etree *left,*right;
};

int etop=-1;
struct Etree *estack[20];
struct Etree *enode;

void epush(struct Etree* enode)
{
    estack[++etop]=enode;
}

struct Etree * epop()
{
    return(estack[etop--]);
}
int echeck(char ch)
{
if(ch=='+'||ch=='-'||ch=='/'||ch=='*')
return 2;
else
return 1;
}
/* Calculating the value of postfix expression using recursion */

int ecal(struct Etree *enode)
{
    int ch;
    ch=echeck(enode->data);
    if(ch==1)
    return enode->data-48;
    else if(ch==2)
    {
        if(enode->data=='+')
            return ecal(enode->left)+ecal(enode->right);
        if(enode->data=='-')
            return ecal(enode->left)-ecal(enode->right);
        if(enode->data=='*')
            return ecal(enode->left)*ecal(enode->right);
        if(enode->data=='/')
            return ecal(enode->left)/ecal(enode->right);
    }
}

/* Displaying all enode in order */

void einorder(struct Etree *enode)
{
    if(enode!=NULL)
    {
    einorder(enode->left);
    printf("%c",enode->data);
    einorder(enode->right);
    }
}

/* Checking operator and operands */



/* making simple operand enode and pushing into estack */

void eoperand(char b)
{
    enode=(struct Etree*)malloc(sizeof(struct Etree));
    enode->data=b;
    enode->left=NULL;
    enode->right=NULL;
    epush(enode);
}

/* making operator enode than pop-up two enodes from estack and adding into operator enode and finally push enode into estack  */

void eoperators(char a)
{
    enode=(struct Etree*)malloc(sizeof(struct Etree));
    enode->data=a;
    enode->right=epop();
    enode->left=epop();
    epush(enode);
}

exptree()
{
    int i,p,k,ans;
    char s[20];

    printf("Enter the expression in postfix form \n");
    fflush(stdin);
    gets(s);
    k=strlen(s);
    i=0;
    for(i=0;s[i]!='\0';i++)
        {
            p=echeck(s[i]);
            if(p==1)
            eoperand(s[i]);
            else if(p==2)
            eoperators(s[i]);
        }
    ans=ecal(estack[etop]);
    printf("\nThe value of the postfix expression you entered is %d\n",ans);
    printf("\nThe inorder traversal of the Etree is \n");
    einorder(estack[etop]);
system("pause");
   system("cls");
   tree1();
}
