#include <stdio.h>
#define MAX 50
int min(int x, int y) { return (x<=y)? x : y; }

int fibMonaccianSearch(int arr[], int x, int n)
{
       int fibMMm2 = 0;

    int fibMMm1 = 1;
    int fibM = fibMMm2 + fibMMm1;

    while (fibM < n)
    {
        fibMMm2 = fibMMm1;
        fibMMm1 = fibM;
        fibM  = fibMMm2 + fibMMm1;
    }

    int offset = -1;

    while (fibM > 1)
    {
        int i = min(offset+fibMMm2, n-1);

        if (arr[i] < x)
        {
            fibM  = fibMMm1;
            fibMMm1 = fibMMm2;
            fibMMm2 = fibM - fibMMm1;
            offset = i;
        }

        else if (arr[i] > x)

        {            fibM  = fibMMm2;
            fibMMm1 = fibMMm1 - fibMMm2;
            fibMMm2 = fibM - fibMMm1;
        }
        else return i;
    }

    if(fibMMm1 && arr[offset+1]==x)return offset+1;

    return -1;
}

fibonacci()
{    int i, size, item, arr[MAX], index;

	printf("Enter the number of elements : ");
	scanf("%d",&size);
	printf("Enter the elements (in sorted order) : \n");
	for(i=0; i<size; i++)
		scanf("%d", &arr[i] );

	printf("Enter the item to be searched : ");
	scanf("%d", &item);
    printf("Found at index: %d",
            fibMonaccianSearch(arr, item, size));
            system("pause");
   system("cls");
   search1();
    return 0;}


