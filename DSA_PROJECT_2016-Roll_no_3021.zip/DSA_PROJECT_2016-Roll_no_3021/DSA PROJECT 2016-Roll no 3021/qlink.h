
#include<stdio.h>
#include<stdlib.h>

struct queue
{
	int info;
	struct queue *link;
}*qlfront=NULL,*qlrear=NULL;

void qlinsert(int item);
int qldel();
int qlpeek();
int qlisEmpty();
void qldisplay();

qlink()
{
	int choice,item;
	while(1)
	{
		printf("1.Insert\n");
		printf("2.Delete\n");
		printf("3.Display the element at the qlfront\n");
		printf("4.Display all elements of the queue\n");
		printf("5.for another option\n");
		printf("Enter your choice : ");
		scanf("%d", &choice);

		switch(choice)
		{
		case 1:
			printf("Input the element for adding in queue : ");
			scanf("%d",&item);
			qlinsert(item);
			break;
		case 2:
			printf("Deleted element is  %d\n",qldel());
			break;
		case 3:
			printf("Element at the qlfront of the queue is %d\n", qlpeek() );
			break;
		case 4:
			qldisplay();
			break;
		case 5:
			queue1();
			break;

		default :
			printf("Wrong choice\n");
		}
		system("pause");
   system("cls");
	}
}

void qlinsert(int item)
{
	struct queue *tmp;
	tmp=(struct queue *)malloc(sizeof(struct queue));
	if(tmp==NULL)
	{
		printf("Memory not available\n");
		return;
	}
	tmp->info = item;
	tmp->link=NULL;
	if(qlfront==NULL)
		qlfront=tmp;
	else
		qlrear->link=tmp;
	qlrear=tmp;
}

int qldel()
{
	struct queue *tmp;
	int item;
	if( qlisEmpty( ) )
	{
		printf("Queue Underflow\n");
qlink();
	}
	tmp=qlfront;
	item=tmp->info;
	qlfront=qlfront->link;
	free(tmp);
	return item;
}

int qlpeek()
{
	if( qlisEmpty( ) )
	{
		printf("Queue Underflow\n");
		qlink();
	}
	return qlfront->info;
}

int qlisEmpty()
{
	if(qlfront==NULL)
		return 1;
	else
		return 0;

}

void qldisplay()
{
	struct queue *ptr;
	ptr=qlfront;
	if(qlisEmpty())
	{
		printf("Queue is empty\n");
		return;
	}
	printf("Queue elements :\n\n");
	while(ptr!=NULL)
	{
		printf("%d ",ptr->info);
		ptr=ptr->link;
	}
	printf("\n\n");
}


