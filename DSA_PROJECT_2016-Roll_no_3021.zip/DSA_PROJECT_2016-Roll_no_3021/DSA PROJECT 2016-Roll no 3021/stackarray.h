

#include<stdio.h>
#include<stdlib.h>
#define MAX 10


int stack_arr[MAX];
int stop = -1;

void spush(int item);
int spop();
int speek();
int sisEmpty();
int sisFull();
void stdisplay();

s()
{
	int choice,item;
	while(1)
	{
		printf("1.Push\n");
		printf("2.Pop\n");
		printf("3.Display the stop element\n");
		printf("4.Display all stack elements\n");
		printf("5.for another option\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);
		switch(choice)
		{
		 case 1 :
			printf("Enter the item to be pushed : ");
			scanf("%d",&item);
			spush(item);
			break;
		 case 2:
			item = spop();
			printf("Popped item is : %d\n",item );
			break;
		 case 3:
			printf("Item at the stop is : %d\n", speek() );
			break;
		 case 4:
			stdisplay();
			break;
		 case 5:
			stack1();
			break;
		 default:
			printf("Wrong choice\n");
		}system("pause");
   system("cls");}
}

void spush(int item)
{
	if( sisFull() )
	{
		printf("Stack Overflow\n");
		return;
	}
	stop = stop+1;
	stack_arr[stop] = item;
}/*End of push()*/

int spop()
{
	int item;
	if( sisEmpty() )
	{
		printf("Stack Underflow\n");
		s();
	}
	item = stack_arr[stop];
	stop = stop-1;
	return item;
}/*End of pop()*/

int speek()
{
	if( sisEmpty() )
	{
		printf("Stack Underflow\n");
		s();
	}
	return stack_arr[stop];
}/*End of peek()*/

int sisEmpty()
{
	if( stop == -1 )
		return 1;
	else
		return 0;
}/*End of isEmpty*/

int sisFull()
{
	if( stop == MAX-1 )
		return 1;
	else
		return 0;
}/*End of isFull*/

void stdisplay()
{
	int i;
	if( sisEmpty() )
	{
		printf("Stack is empty\n");
		return;
	}
    printf("Stack elements :\n\n");
	for(i=stop;i>=0;i--)
		printf(" %d\n", stack_arr[i] );
	printf("\n");
}/*End of display()*/



