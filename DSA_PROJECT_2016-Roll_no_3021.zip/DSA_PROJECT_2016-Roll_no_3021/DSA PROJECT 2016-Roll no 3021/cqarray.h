
#include<stdio.h>
#include<stdlib.h>
#define MAX 10

int cqueue_arr[MAX];
int cqfront=-1;
int cqrear=-1;

void cqdisplay( );
void cqinsert(item);
int cqdel();
int cqpeek();
int cqisEmpty();
int cqisFull();

cq()
{
	int choice,item;
	while(1)
	{
		printf("1.Insert\n");
		printf("2.Delete\n");
		printf("3.Peek\n");
		printf("4.Display\n");
		printf("5.for another option\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		case 1 :
			printf("Input the element for insertion : ");
			scanf("%d",&item);
			cqinsert(item);
			break;
		case 2 :
			printf("Element deleted is : %d\n",cqdel());
			break;
		case 3:
			printf("Element at the cqfront is  : %d\n",cqpeek());
			break;
		case 4:
			cqdisplay();
			break;
		case 5:
			queue1();
			break;
		default:
			printf("Wrong choice\n");
		}
		system("pause");
   system("cls");}}
void cqinsert(int item)
{
	if( cqisFull() )
	{
		printf("Queue Overflow\n");
		return;
	}
	if(cqfront == -1 )
		cqfront=0;

	if(cqrear==MAX-1)/*cqrear is at last position of queue*/
		cqrear=0;
	else
		cqrear=cqrear+1;
	cqueue_arr[cqrear]=item ;
}/*End of insert()*/

int cqdel()
{
	int item;
	if( cqisEmpty() )
	{
		printf("Queue Underflow\n");
		cq();
	}
	item=cqueue_arr[cqfront];
	if(cqfront==cqrear) /* queue has only one element */
	{
		cqfront=-1;
		cqrear=-1;
	}
	else if(cqfront==MAX-1)
		cqfront=0;
	else
		cqfront=cqfront+1;
	return item;
}/*End of del() */

int cqisEmpty()
{
	if(cqfront==-1)
		return 1;
	else
		return 0;
}/*End of isEmpty()*/

int cqisFull()
{
	if((cqfront==0 && cqrear==MAX-1) || (cqfront==cqrear+1))
		return 1;
	else
		return 0;
}/*End of isFull()*/

int cqpeek()
{
	if( cqisEmpty() )
	{
		printf("Queue Underflow\n");
cq();
	}
	return cqueue_arr[cqfront];
}/*End of peek()*/

void cqdisplay()
{
	int i;
	if(cqisEmpty())
	{
		printf("Queue is empty\n");
		return;
	}
	printf("Queue elements :\n");
	i=cqfront;
	if( cqfront<=cqrear )
	{
		while(i<=cqrear)
			printf("%d ",cqueue_arr[i++]);
	}
	else
	{
		while(i<=MAX-1)
			printf("%d ",cqueue_arr[i++]);
		i=0;
		while(i<=cqrear)
			printf("%d ",cqueue_arr[i++]);
	}
	printf("\n");
}/*End of display() */

