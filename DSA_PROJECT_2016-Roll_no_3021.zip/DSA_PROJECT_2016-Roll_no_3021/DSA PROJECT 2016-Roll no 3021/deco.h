
void getout()
{
    int i;
    for(i=0;i<97;i++)
        printf("=");
    printf("\nSubmitted By:\t\t\t\t\t\t\t\t\tSubmitted To:  \t|\n");
    for(i=0;i<97;i++)
        printf("=");
    printf("\nMr. Ashish Kumar\t\t\t\t\t\t\t\tRohit Kumar    \t|\n");
    printf("\nAsst. Professor\t\t\t\t\t\t\t\t\t15103083    \t|\n");
    printf("\nDept. of CSE   \t\t\t\t\t\t\t\t\t3rd Semester   \t|\n");
    for(i=0;i<97;i++)
        printf("=");
    getch();
    return;
}

void show()
{
    int i;
     for(i=0;i<97;i++)
        printf("=");
    printf("\n\t\t\t\tDATA STRUCTURE AND ALGORITHMS\n");
    for(i=0;i<97;i++)
        printf("=");
    printf("\n");
}
